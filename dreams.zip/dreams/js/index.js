    $(function(){      
     
       //jCarousel
       $('.vartical-slider').jCarousel({
          type:'slidey-up'
       });       
     
    }); 